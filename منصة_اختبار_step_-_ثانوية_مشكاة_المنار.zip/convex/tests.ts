import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// إنشاء اختبار جديد
export const createTest = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    subject: v.string(),
    grade: v.string(),
    duration: v.number(),
    instructions: v.optional(v.string()),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // التحقق من أن المستخدم معلم
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "teacher") {
      throw new Error("المعلمون فقط يمكنهم إنشاء الاختبارات");
    }

    return await ctx.db.insert("tests", {
      ...args,
      createdBy: userId,
      totalMarks: 0, // سيتم تحديثه عند إضافة الأسئلة
      difficulty: "medium", // قيمة افتراضية
      isActive: true,
    });
  },
});

// إضافة سؤال للاختبار
export const addQuestion = mutation({
  args: {
    testId: v.id("tests"),
    questionText: v.string(),
    questionType: v.union(
      v.literal("multiple_choice"),
      v.literal("true_false"),
      v.literal("essay")
    ),
    options: v.optional(v.array(v.string())),
    correctAnswer: v.string(),
    marks: v.number(),
    explanation: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // التحقق من ملكية الاختبار
    const test = await ctx.db.get(args.testId);
    if (!test || test.createdBy !== userId) {
      throw new Error("غير مصرح لك بتعديل هذا الاختبار");
    }

    // الحصول على ترتيب السؤال التالي
    const existingQuestions = await ctx.db
      .query("questions")
      .withIndex("by_test", (q) => q.eq("testId", args.testId))
      .collect();

    const order = existingQuestions.length + 1;

    const questionId = await ctx.db.insert("questions", {
      ...args,
      order,
    });

    // تحديث إجمالي درجات الاختبار
    const newTotalMarks = test.totalMarks + args.marks;
    await ctx.db.patch(args.testId, { totalMarks: newTotalMarks });

    return questionId;
  },
});

// الحصول على اختبارات المعلم
export const getTeacherTests = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    return await ctx.db
      .query("tests")
      .withIndex("by_creator", (q) => q.eq("createdBy", userId))
      .order("desc")
      .collect();
  },
});

// الحصول على الاختبارات المتاحة للطالب
export const getAvailableTests = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // الحصول على بيانات الطالب
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "student") {
      throw new Error("الطلاب فقط يمكنهم رؤية الاختبارات");
    }

    // الحصول على الاختبارات المناسبة لصف الطالب
    const tests = await ctx.db
      .query("tests")
      .withIndex("by_grade", (q) => q.eq("grade", userProfile.grade || ""))
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();

    const now = Date.now();
    
    return tests.filter((test) => {
      // التحقق من تاريخ البداية والنهاية
      if (test.startDate && test.startDate > now) return false;
      if (test.endDate && test.endDate < now) return false;
      return true;
    });
  },
});

// بدء محاولة اختبار
export const startTestAttempt = mutation({
  args: { testId: v.id("tests") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // التحقق من وجود محاولة سابقة
    const existingAttempt = await ctx.db
      .query("testAttempts")
      .withIndex("by_test_student", (q) => 
        q.eq("testId", args.testId).eq("studentId", userId)
      )
      .filter((q) => q.neq(q.field("status"), "abandoned"))
      .first();

    if (existingAttempt) {
      if (existingAttempt.status === "completed") {
        throw new Error("لقد أكملت هذا الاختبار بالفعل");
      }
      return existingAttempt._id; // إرجاع المحاولة الجارية
    }

    // حساب رقم المحاولة
    const previousAttempts = await ctx.db
      .query("testAttempts")
      .withIndex("by_test_student", (q) => q.eq("testId", args.testId).eq("studentId", userId))
      .collect();

    return await ctx.db.insert("testAttempts", {
      testId: args.testId,
      studentId: userId,
      attemptNumber: previousAttempts.length + 1,
      startTime: Date.now(),
      status: "in_progress",
    });
  },
});

// الحصول على أسئلة الاختبار
export const getTestQuestions = query({
  args: { testId: v.id("tests") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    return await ctx.db
      .query("questions")
      .withIndex("by_test", (q) => q.eq("testId", args.testId))
      .order("asc")
      .collect();
  },
});

// حفظ إجابة الطالب
export const saveAnswer = mutation({
  args: {
    attemptId: v.id("testAttempts"),
    questionId: v.id("questions"),
    answer: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // التحقق من ملكية المحاولة
    const attempt = await ctx.db.get(args.attemptId);
    if (!attempt || attempt.studentId !== userId) {
      throw new Error("غير مصرح لك بحفظ هذه الإجابة");
    }

    // البحث عن إجابة سابقة
    const existingAnswer = await ctx.db
      .query("studentAnswers")
      .withIndex("by_attempt", (q) => q.eq("attemptId", args.attemptId))
      .filter((q) => q.eq(q.field("questionId"), args.questionId))
      .first();

    if (existingAnswer) {
      await ctx.db.patch(existingAnswer._id, { answer: args.answer });
      return existingAnswer._id;
    } else {
      return await ctx.db.insert("studentAnswers", args);
    }
  },
});

// إنهاء الاختبار وحساب النتيجة
export const completeTest = mutation({
  args: { attemptId: v.id("testAttempts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    const attempt = await ctx.db.get(args.attemptId);
    if (!attempt || attempt.studentId !== userId) {
      throw new Error("غير مصرح لك بإنهاء هذا الاختبار");
    }

    // الحصول على الأسئلة والإجابات
    const questions = await ctx.db
      .query("questions")
      .withIndex("by_test", (q) => q.eq("testId", attempt.testId))
      .collect();

    const answers = await ctx.db
      .query("studentAnswers")
      .withIndex("by_attempt", (q) => q.eq("attemptId", args.attemptId))
      .collect();

    let totalScore = 0;
    const test = await ctx.db.get(attempt.testId);

    // تصحيح الإجابات
    for (const answer of answers) {
      const question = questions.find(q => q._id === answer.questionId);
      if (question) {
        const isCorrect = answer.answer.trim().toLowerCase() === 
                         question.correctAnswer.trim().toLowerCase();
        const marksAwarded = isCorrect ? question.marks : 0;
        
        await ctx.db.patch(answer._id, {
          isCorrect,
          marksAwarded,
        });

        totalScore += marksAwarded;
      }
    }

    const percentage = test ? (totalScore / test.totalMarks) * 100 : 0;
    const endTime = Date.now();
    const timeSpent = Math.floor((endTime - attempt.startTime) / 1000);

    await ctx.db.patch(args.attemptId, {
      status: "completed",
      endTime,
      totalScore,
      percentage: Math.round(percentage * 100) / 100,
      timeSpent,
    });

    return {
      totalScore,
      percentage: Math.round(percentage * 100) / 100,
      timeSpent,
    };
  },
});

import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // جدول المستخدمين مع معلومات إضافية
  userProfiles: defineTable({
    userId: v.id("users"),
    role: v.union(v.literal("teacher"), v.literal("student")),
    fullName: v.string(),
    studentId: v.optional(v.string()), // للطلاب فقط
    grade: v.optional(v.string()), // الصف الدراسي
    classLevel: v.optional(v.string()), // مستوى الصف (بدلاً من المجموعة)
    section: v.optional(v.string()), // حقل قديم - مؤقت للتوافق
    phone: v.optional(v.string()),
    avatar: v.optional(v.id("_storage")),
    isActive: v.boolean(),
    specialization: v.optional(v.string()), // التخصص
    birthDate: v.optional(v.string()), // تاريخ الميلاد
    city: v.optional(v.string()), // المدينة
    parentPhone: v.optional(v.string()), // هاتف ولي الأمر
    emergencyContact: v.optional(v.string()), // جهة اتصال طوارئ
    notes: v.optional(v.string()), // ملاحظات إضافية
  }).index("by_user_id", ["userId"])
    .index("by_role", ["role"])
    .index("by_student_id", ["studentId"])
    .index("by_grade", ["grade"])
    .index("by_class_level", ["classLevel"]),

  // جدول الاختبارات
  tests: defineTable({
    title: v.string(),
    description: v.string(),
    subject: v.string(), // المادة
    grade: v.string(), // الصف المستهدف
    difficulty: v.optional(v.union(v.literal("easy"), v.literal("medium"), v.literal("hard"))), // مستوى الصعوبة - اختياري مؤقتاً
    duration: v.number(), // مدة الاختبار بالدقائق
    totalMarks: v.number(),
    passingScore: v.optional(v.number()), // درجة النجاح
    createdBy: v.id("users"), // المعلم الذي أنشأ الاختبار
    isActive: v.boolean(),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
    instructions: v.optional(v.string()),
    tags: v.optional(v.array(v.string())), // علامات للتصنيف
    maxAttempts: v.optional(v.number()), // عدد المحاولات المسموحة
    showResults: v.optional(v.boolean()), // إظهار النتائج فوراً
    randomizeQuestions: v.optional(v.boolean()), // ترتيب عشوائي للأسئلة
  }).index("by_creator", ["createdBy"])
    .index("by_grade", ["grade"])
    .index("by_subject", ["subject"])
    .index("by_difficulty", ["difficulty"])
    .index("by_active", ["isActive"]),

  // جدول الأسئلة
  questions: defineTable({
    testId: v.id("tests"),
    questionText: v.string(),
    questionType: v.union(
      v.literal("multiple_choice"),
      v.literal("true_false"),
      v.literal("essay"),
      v.literal("fill_blank"),
      v.literal("matching")
    ),
    options: v.optional(v.array(v.string())), // للأسئلة متعددة الخيارات
    correctAnswer: v.string(),
    marks: v.number(),
    order: v.number(),
    explanation: v.optional(v.string()),
    difficulty: v.optional(v.union(v.literal("easy"), v.literal("medium"), v.literal("hard"))),
    category: v.optional(v.string()), // تصنيف السؤال
    timeLimit: v.optional(v.number()), // وقت محدد للسؤال
    image: v.optional(v.id("_storage")), // صورة مرفقة
  }).index("by_test", ["testId"])
    .index("by_order", ["testId", "order"])
    .index("by_difficulty", ["difficulty"])
    .index("by_category", ["category"]),

  // جدول محاولات الطلاب
  testAttempts: defineTable({
    testId: v.id("tests"),
    studentId: v.id("users"),
    attemptNumber: v.optional(v.number()), // رقم المحاولة - اختياري مؤقتاً
    startTime: v.number(),
    endTime: v.optional(v.number()),
    status: v.union(
      v.literal("in_progress"),
      v.literal("completed"),
      v.literal("abandoned"),
      v.literal("paused")
    ),
    totalScore: v.optional(v.number()),
    percentage: v.optional(v.number()),
    timeSpent: v.optional(v.number()), // بالثواني
    correctAnswers: v.optional(v.number()),
    wrongAnswers: v.optional(v.number()),
    skippedAnswers: v.optional(v.number()),
    grade: v.optional(v.string()), // تقدير (ممتاز، جيد جداً، إلخ)
    feedback: v.optional(v.string()), // تعليق المدرس
  }).index("by_test", ["testId"])
    .index("by_student", ["studentId"])
    .index("by_test_student", ["testId", "studentId"])
    .index("by_status", ["status"]),

  // جدول إجابات الطلاب
  studentAnswers: defineTable({
    attemptId: v.id("testAttempts"),
    questionId: v.id("questions"),
    answer: v.string(),
    isCorrect: v.optional(v.boolean()),
    marksAwarded: v.optional(v.number()),
    timeSpent: v.optional(v.number()), // وقت الإجابة على السؤال
    confidence: v.optional(v.number()), // مستوى الثقة في الإجابة (1-5)
    flagged: v.optional(v.boolean()), // مُعلم للمراجعة
  }).index("by_attempt", ["attemptId"])
    .index("by_question", ["questionId"])
    .index("by_flagged", ["flagged"]),

  // جدول الإحصائيات
  statistics: defineTable({
    testId: v.id("tests"),
    totalAttempts: v.number(),
    averageScore: v.number(),
    highestScore: v.number(),
    lowestScore: v.number(),
    passRate: v.number(), // نسبة النجاح
    averageTime: v.number(), // متوسط الوقت المستغرق
    lastUpdated: v.number(),
    difficultyAnalysis: v.optional(v.object({
      easy: v.number(),
      medium: v.number(),
      hard: v.number(),
    })),
  }).index("by_test", ["testId"]),

  // جدول الإشعارات المحسن
  notifications: defineTable({
    userId: v.id("users"),
    title: v.string(),
    message: v.string(),
    type: v.union(
      v.literal("test_assigned"),
      v.literal("test_completed"),
      v.literal("grade_published"),
      v.literal("system"),
      v.literal("reminder"),
      v.literal("achievement"),
      v.literal("message_received")
    ),
    isRead: v.boolean(),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    relatedTestId: v.optional(v.id("tests")),
    actionUrl: v.optional(v.string()),
    expiresAt: v.optional(v.number()),
    icon: v.optional(v.string()),
    color: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_unread", ["userId", "isRead"])
    .index("by_priority", ["priority"])
    .index("by_type", ["type"]),

  // جدول الرسائل بين المستخدمين والمسؤول
  userMessages: defineTable({
    fromUserId: v.id("users"),
    toUserId: v.id("users"),
    subject: v.string(),
    message: v.string(),
    isRead: v.boolean(),
    sentAt: v.number(),
    replyToId: v.optional(v.id("userMessages")), // للردود
    priority: v.optional(v.union(v.literal("low"), v.literal("medium"), v.literal("high"))),
    category: v.optional(v.string()), // تصنيف الرسالة
    attachments: v.optional(v.array(v.id("_storage"))), // مرفقات
    isArchived: v.optional(v.boolean()),
  }).index("by_sender", ["fromUserId"])
    .index("by_receiver", ["toUserId"])
    .index("by_conversation", ["fromUserId", "toUserId"])
    .index("by_priority", ["priority"])
    .index("by_category", ["category"]),

  // جدول الإنجازات والشارات
  achievements: defineTable({
    userId: v.id("users"),
    type: v.union(
      v.literal("first_test"),
      v.literal("perfect_score"),
      v.literal("fast_completion"),
      v.literal("consistent_performer"),
      v.literal("improvement"),
      v.literal("participation")
    ),
    title: v.string(),
    description: v.string(),
    icon: v.string(),
    earnedAt: v.number(),
    testId: v.optional(v.id("tests")),
    points: v.number(),
  }).index("by_user", ["userId"])
    .index("by_type", ["type"])
    .index("by_earned_date", ["earnedAt"]),

  // جدول الأنشطة والسجلات
  activityLogs: defineTable({
    userId: v.id("users"),
    action: v.string(),
    details: v.string(),
    timestamp: v.number(),
    relatedId: v.optional(v.string()),
    relatedType: v.optional(v.string()),
    ipAddress: v.optional(v.string()),
    userAgent: v.optional(v.string()),
  }).index("by_user", ["userId"])
    .index("by_timestamp", ["timestamp"])
    .index("by_action", ["action"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});

import { mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// حذف الحساب نهائياً
export const deleteAccount = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // حذف الملف الشخصي
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (userProfile) {
      await ctx.db.delete(userProfile._id);
    }

    // حذف محاولات الاختبارات
    const testAttempts = await ctx.db
      .query("testAttempts")
      .withIndex("by_student", (q) => q.eq("studentId", userId))
      .collect();

    for (const attempt of testAttempts) {
      // حذف إجابات الطالب
      const answers = await ctx.db
        .query("studentAnswers")
        .withIndex("by_attempt", (q) => q.eq("attemptId", attempt._id))
        .collect();

      for (const answer of answers) {
        await ctx.db.delete(answer._id);
      }

      await ctx.db.delete(attempt._id);
    }

    // حذف الاختبارات إذا كان معلماً
    if (userProfile?.role === "teacher") {
      const tests = await ctx.db
        .query("tests")
        .withIndex("by_creator", (q) => q.eq("createdBy", userId))
        .collect();

      for (const test of tests) {
        // حذف الأسئلة
        const questions = await ctx.db
          .query("questions")
          .withIndex("by_test", (q) => q.eq("testId", test._id))
          .collect();

        for (const question of questions) {
          await ctx.db.delete(question._id);
        }

        await ctx.db.delete(test._id);
      }
    }

    // حذف الرسائل
    const sentMessages = await ctx.db
      .query("userMessages")
      .withIndex("by_sender", (q) => q.eq("fromUserId", userId))
      .collect();

    const receivedMessages = await ctx.db
      .query("userMessages")
      .withIndex("by_receiver", (q) => q.eq("toUserId", userId))
      .collect();

    for (const message of [...sentMessages, ...receivedMessages]) {
      await ctx.db.delete(message._id);
    }

    // حذف الإشعارات
    const notifications = await ctx.db
      .query("notifications")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    for (const notification of notifications) {
      await ctx.db.delete(notification._id);
    }

    // حذف الإنجازات
    const achievements = await ctx.db
      .query("achievements")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    for (const achievement of achievements) {
      await ctx.db.delete(achievement._id);
    }

    // حذف سجلات الأنشطة
    const activityLogs = await ctx.db
      .query("activityLogs")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    for (const log of activityLogs) {
      await ctx.db.delete(log._id);
    }

    // أخيراً حذف المستخدم نفسه
    await ctx.db.delete(userId);

    return { success: true };
  },
});

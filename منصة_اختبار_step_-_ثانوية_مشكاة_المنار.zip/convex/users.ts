import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// الحصول على المستخدم الحالي مع بياناته الإضافية
export const getCurrentUser = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const user = await ctx.db.get(userId);
    if (!user) return null;

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    return {
      ...user,
      profile,
    };
  },
});

// إنشاء أو تحديث ملف المستخدم
export const createOrUpdateProfile = mutation({
  args: {
    role: v.union(v.literal("teacher"), v.literal("student")),
    fullName: v.string(),
    studentId: v.optional(v.string()),
    grade: v.optional(v.string()),
    classLevel: v.optional(v.string()),
    phone: v.optional(v.string()),
    specialization: v.optional(v.string()),
    birthDate: v.optional(v.string()),
    city: v.optional(v.string()),
    parentPhone: v.optional(v.string()),
    emergencyContact: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (existingProfile) {
      await ctx.db.patch(existingProfile._id, {
        ...args,
        isActive: true,
      });
      return existingProfile._id;
    } else {
      return await ctx.db.insert("userProfiles", {
        userId,
        ...args,
        isActive: true,
      });
    }
  },
});

// الحصول على جميع الطلاب (للمعلمين)
export const getAllStudents = query({
  args: {
    grade: v.optional(v.string()),
    classLevel: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // التحقق من أن المستخدم معلم
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "teacher") {
      throw new Error("غير مصرح لك بالوصول");
    }

    // الحصول على جميع الطلاب النشطين
    let studentsQuery = ctx.db
      .query("userProfiles")
      .withIndex("by_role", (q) => q.eq("role", "student"));

    const allStudents = await studentsQuery.collect();

    // تصفية حسب الصف ومستوى الصف إذا تم تحديدهما
    const filteredStudents = allStudents.filter((student) => {
      // التحقق من أن الطالب نشط
      if (!student.isActive) return false;
      
      // تصفية حسب الصف
      if (args.grade && student.grade !== args.grade) return false;
      
      // تصفية حسب مستوى الصف
      if (args.classLevel && student.classLevel !== args.classLevel) return false;
      
      return true;
    });

    return filteredStudents;
  },
});

// الحصول على إحصائيات الطلاب
export const getStudentStats = query({
  args: { studentId: v.id("users") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // الحصول على جميع محاولات الطالب
    const attempts = await ctx.db
      .query("testAttempts")
      .withIndex("by_student", (q) => q.eq("studentId", args.studentId))
      .filter((q) => q.eq(q.field("status"), "completed"))
      .collect();

    const totalTests = attempts.length;
    const totalScore = attempts.reduce((sum, attempt) => sum + (attempt.totalScore || 0), 0);
    const averageScore = totalTests > 0 ? totalScore / totalTests : 0;
    const passedTests = attempts.filter((attempt) => (attempt.percentage || 0) >= 50).length;

    return {
      totalTests,
      averageScore: Math.round(averageScore * 100) / 100,
      passRate: totalTests > 0 ? Math.round((passedTests / totalTests) * 100) : 0,
      lastTestDate: attempts.length > 0 ? Math.max(...attempts.map(a => a.startTime)) : null,
    };
  },
});

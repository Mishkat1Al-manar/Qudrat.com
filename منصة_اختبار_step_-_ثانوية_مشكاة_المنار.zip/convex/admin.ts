import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

// إنشاء حساب المسؤول (يتم استدعاؤه مرة واحدة فقط)
export const createAdminAccount = mutation({
  args: {},
  handler: async (ctx) => {
    // التحقق من وجود المسؤول مسبقاً
    const existingAdmin = await ctx.db
      .query("users")
      .filter((q) => q.eq(q.field("email"), "admin@gmail.com"))
      .first();

    if (existingAdmin) {
      return { message: "حساب المسؤول موجود بالفعل", adminId: existingAdmin._id };
    }

    // إنشاء حساب المسؤول
    const adminId = await ctx.db.insert("users", {
      name: "المسؤول العام",
      email: "admin@gmail.com",
      emailVerificationTime: Date.now(),
      isAnonymous: false,
    });

    // إنشاء ملف شخصي للمسؤول
    await ctx.db.insert("userProfiles", {
      userId: adminId,
      role: "teacher",
      fullName: "المسؤول العام",
      isActive: true,
      specialization: "إدارة المنصة",
      city: "الرياض",
    });

    return { message: "تم إنشاء حساب المسؤول بنجاح", adminId };
  },
});

// التحقق من حالة حساب المسؤول
export const checkAdminStatus = query({
  args: {},
  handler: async (ctx) => {
    const admin = await ctx.db
      .query("users")
      .filter((q) => q.eq(q.field("email"), "admin@gmail.com"))
      .first();

    return {
      exists: !!admin,
      adminId: admin?._id,
    };
  },
});

// الحصول على إحصائيات المنصة (للمسؤول فقط)
export const getPlatformStats = query({
  args: {},
  handler: async (ctx) => {
    // عدد المستخدمين
    const totalUsers = await ctx.db.query("userProfiles").collect();
    const teachers = totalUsers.filter(u => u.role === "teacher").length;
    const students = totalUsers.filter(u => u.role === "student").length;

    // عدد الاختبارات
    const totalTests = await ctx.db.query("tests").collect();
    const activeTests = totalTests.filter(t => t.isActive).length;

    // عدد محاولات الاختبارات
    const totalAttempts = await ctx.db.query("testAttempts").collect();
    const completedAttempts = totalAttempts.filter(a => a.status === "completed").length;

    // عدد الرسائل
    const totalMessages = await ctx.db.query("userMessages").collect();

    return {
      users: {
        total: totalUsers.length,
        teachers,
        students,
      },
      tests: {
        total: totalTests.length,
        active: activeTests,
      },
      attempts: {
        total: totalAttempts.length,
        completed: completedAttempts,
      },
      messages: totalMessages.length,
    };
  },
});

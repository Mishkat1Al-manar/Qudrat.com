import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// إرسال رسالة للمسؤول (admin@gmail.com فقط)
export const sendMessageToAdmin = mutation({
  args: {
    subject: v.string(),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user_id", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile) throw new Error("الملف الشخصي غير موجود");

    // البحث عن المسؤول الوحيد admin@gmail.com
    const adminUser = await ctx.db
      .query("users")
      .filter((q) => q.eq(q.field("email"), "admin@gmail.com"))
      .first();

    if (!adminUser) throw new Error("المسؤول غير متاح حالياً");

    return await ctx.db.insert("userMessages", {
      fromUserId: userId,
      toUserId: adminUser._id,
      subject: args.subject,
      message: args.message,
      isRead: false,
      sentAt: Date.now(),
    });
  },
});

// الحصول على رسائل المستخدم
export const getUserMessages = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    const sentMessages = await ctx.db
      .query("userMessages")
      .withIndex("by_sender", (q) => q.eq("fromUserId", userId))
      .order("desc")
      .collect();

    const receivedMessages = await ctx.db
      .query("userMessages")
      .withIndex("by_receiver", (q) => q.eq("toUserId", userId))
      .order("desc")
      .collect();

    // إضافة معلومات المرسل والمستقبل
    const allMessages = [...sentMessages, ...receivedMessages].sort(
      (a, b) => b.sentAt - a.sentAt
    );

    const messagesWithProfiles = await Promise.all(
      allMessages.map(async (message) => {
        const fromProfile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user_id", (q) => q.eq("userId", message.fromUserId))
          .unique();

        const toProfile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user_id", (q) => q.eq("userId", message.toUserId))
          .unique();

        // الحصول على بيانات المستخدم للمسؤول
        const fromUser = await ctx.db.get(message.fromUserId);
        const toUser = await ctx.db.get(message.toUserId);

        return {
          ...message,
          fromProfile,
          toProfile,
          fromUser,
          toUser,
          isSent: message.fromUserId === userId,
        };
      })
    );

    return messagesWithProfiles;
  },
});

// الرد على رسالة
export const replyToMessage = mutation({
  args: {
    originalMessageId: v.id("userMessages"),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    const originalMessage = await ctx.db.get(args.originalMessageId);
    if (!originalMessage) throw new Error("الرسالة الأصلية غير موجودة");

    // تحديد المستقبل (إذا كان المرسل الأصلي هو المستخدم الحالي، فالرد للمستقبل الأصلي)
    const toUserId = originalMessage.fromUserId === userId 
      ? originalMessage.toUserId 
      : originalMessage.fromUserId;

    return await ctx.db.insert("userMessages", {
      fromUserId: userId,
      toUserId,
      subject: `رد: ${originalMessage.subject}`,
      message: args.message,
      isRead: false,
      sentAt: Date.now(),
      replyToId: args.originalMessageId,
    });
  },
});

// تحديد الرسالة كمقروءة
export const markMessageAsRead = mutation({
  args: { messageId: v.id("userMessages") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    const message = await ctx.db.get(args.messageId);
    if (!message || message.toUserId !== userId) {
      throw new Error("غير مصرح لك بتحديث هذه الرسالة");
    }

    await ctx.db.patch(args.messageId, { isRead: true });
  },
});

// الحصول على عدد الرسائل غير المقروءة
export const getUnreadMessagesCount = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return 0;

    const unreadMessages = await ctx.db
      .query("userMessages")
      .withIndex("by_receiver", (q) => q.eq("toUserId", userId))
      .filter((q) => q.eq(q.field("isRead"), false))
      .collect();

    return unreadMessages.length;
  },
});

// للمسؤول: الحصول على جميع الرسائل
export const getAllMessagesForAdmin = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("غير مصرح لك بالوصول");

    // التحقق من أن المستخدم هو المسؤول
    const user = await ctx.db.get(userId);
    if (!user || user.email !== "admin@gmail.com") {
      throw new Error("هذه الوظيفة متاحة للمسؤول فقط");
    }

    const allMessages = await ctx.db
      .query("userMessages")
      .order("desc")
      .collect();

    const messagesWithProfiles = await Promise.all(
      allMessages.map(async (message) => {
        const fromProfile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user_id", (q) => q.eq("userId", message.fromUserId))
          .unique();

        const toProfile = await ctx.db
          .query("userProfiles")
          .withIndex("by_user_id", (q) => q.eq("userId", message.toUserId))
          .unique();

        const fromUser = await ctx.db.get(message.fromUserId);
        const toUser = await ctx.db.get(message.toUserId);

        return {
          ...message,
          fromProfile,
          toProfile,
          fromUser,
          toUser,
        };
      })
    );

    return messagesWithProfiles;
  },
});

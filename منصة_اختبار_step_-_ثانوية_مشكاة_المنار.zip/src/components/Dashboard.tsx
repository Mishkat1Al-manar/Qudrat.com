import { useState } from "react";
import { TeacherDashboard } from "./TeacherDashboard";
import { StudentDashboard } from "./StudentDashboard";
import { AdminDashboard } from "./AdminDashboard";

interface DashboardProps {
  user: {
    name?: string;
    email?: string;
    profile: {
      role: "teacher" | "student";
      fullName: string;
      grade?: string;
      classLevel?: string;
      specialization?: string;
      city?: string;
    };
  };
}

export function Dashboard({ user }: DashboardProps) {
  // التحقق من المسؤول
  const isAdmin = user.email === "admin@gmail.com";

  return (
    <div className="space-y-6">
      {/* ترحيب محسن */}
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 rounded-3xl p-8 text-white">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10 flex items-center justify-between">
          <div className="space-y-2">
            <div className="flex items-center space-x-3 space-x-reverse">
              <span className="text-4xl">
                {isAdmin ? "👨‍💼" : user.profile.role === "teacher" ? "👨‍🏫" : "👨‍🎓"}
              </span>
              <div>
                <h2 className="text-3xl font-bold mb-1">
                  مرحباً، {isAdmin ? "المسؤول العام" : user.profile.fullName}
                </h2>
                <p className="text-blue-100 text-lg">
                  {isAdmin 
                    ? "🔧 مسؤول المنصة" 
                    : user.profile.role === "teacher" 
                      ? "🎯 مدرب قدرات محترف" 
                      : "🚀 متدرب طموح"
                  }
                </p>
              </div>
            </div>
            
            {!isAdmin && (
              <div className="flex flex-wrap items-center gap-3 mt-4">
              {user.profile.grade && (
                <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium">
                  📚 {user.profile.grade}
                </span>
              )}
              {user.profile.classLevel && (
                <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium">
                  🎯 {user.profile.classLevel}
                </span>
              )}
              {user.profile.specialization && (
                <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium">
                  🔬 {user.profile.specialization}
                </span>
              )}
              {user.profile.city && (
                <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium">
                  📍 {user.profile.city}
                </span>
              )}
            </div>
            )}
          </div>
          
          <div className="hidden md:block">
            <div className="text-8xl opacity-20 animate-pulse">
              {isAdmin ? "⚙️" : user.profile.role === "teacher" ? "🎓" : "📖"}
            </div>
          </div>
        </div>
        
        {/* تأثير الخلفية */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
      </div>

      {/* لوحة التحكم حسب نوع المستخدم */}
      {isAdmin ? (
        <AdminDashboard />
      ) : user.profile.role === "teacher" ? (
        <TeacherDashboard />
      ) : (
        <StudentDashboard />
      )}
    </div>
  );
}

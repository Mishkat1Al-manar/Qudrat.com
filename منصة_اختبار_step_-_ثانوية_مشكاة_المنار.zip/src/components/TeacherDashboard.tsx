import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { CreateTestModal } from "./CreateTestModal";
import { StudentsView } from "./StudentsView";

export function TeacherDashboard() {
  const [activeTab, setActiveTab] = useState<"tests" | "students" | "analytics">("tests");
  const [showCreateTest, setShowCreateTest] = useState(false);
  
  const tests = useQuery(api.tests.getTeacherTests) || [];
  const students = useQuery(api.users.getAllStudents, {}) || [];

  const tabs = [
    { id: "tests", label: "اختبارات القدرات", icon: "📝", count: tests.length },
    { id: "students", label: "المتدربين", icon: "👥", count: students.length },
    { id: "analytics", label: "التحليلات", icon: "📊", count: null },
  ];

  return (
    <div className="space-y-6">
      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">إجمالي اختبارات القدرات</p>
              <p className="text-2xl font-bold text-gray-900">{tests.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">📝</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">عدد المتدربين</p>
              <p className="text-2xl font-bold text-gray-900">{students.length}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">👥</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">الاختبارات النشطة</p>
              <p className="text-2xl font-bold text-gray-900">
                {tests.filter(t => t.isActive).length}
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">⚡</span>
            </div>
          </div>
        </div>
      </div>

      {/* التبويبات */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 space-x-reverse px-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
              >
                <span className="ml-2">{tab.icon}</span>
                {tab.label}
                {tab.count !== null && (
                  <span className="mr-2 bg-gray-100 text-gray-600 py-1 px-2 rounded-full text-xs">
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "tests" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">اختبارات القدرات</h3>
                <button
                  onClick={() => setShowCreateTest(true)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  إنشاء اختبار قدرات جديد
                </button>
              </div>

              {tests.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">📝</div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد اختبارات قدرات</h3>
                  <p className="text-gray-600 mb-4">ابدأ بإنشاء اختبار القدرات الأول</p>
                  <button
                    onClick={() => setShowCreateTest(true)}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    إنشاء اختبار قدرات
                  </button>
                </div>
              ) : (
                <div className="grid gap-4">
                  {tests.map((test) => (
                    <div key={test._id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 mb-1">{test.title}</h4>
                          <p className="text-gray-600 text-sm mb-2">{test.description}</p>
                          <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-500">
                            <span>📚 {test.subject}</span>
                            <span>🎓 {test.grade}</span>
                            <span>⏱️ {test.duration} دقيقة</span>
                            <span>📊 {test.totalMarks} درجة</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            test.isActive 
                              ? "bg-green-100 text-green-800" 
                              : "bg-gray-100 text-gray-800"
                          }`}>
                            {test.isActive ? "نشط" : "غير نشط"}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "students" && <StudentsView />}

          {activeTab === "analytics" && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📊</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">التحليلات والإحصائيات</h3>
              <p className="text-gray-600">قريباً...</p>
            </div>
          )}
        </div>
      </div>

      {showCreateTest && (
        <CreateTestModal onClose={() => setShowCreateTest(false)} />
      )}
    </div>
  );
}

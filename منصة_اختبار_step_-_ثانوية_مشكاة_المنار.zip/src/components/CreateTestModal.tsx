import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface CreateTestModalProps {
  onClose: () => void;
}

export function CreateTestModal({ onClose }: CreateTestModalProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    subject: "",
    grade: "",
    duration: 120,
    instructions: "",
    startDate: "",
    endDate: "",
  });

  const createTest = useMutation(api.tests.createTest);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const subjects = [
    "القدرات العامة - الجزء الكمي",
    "القدرات العامة - الجزء اللفظي",
    "القدرات العامة - اختبار شامل",
    "القدرات المحوسبة - الرياضيات",
    "القدرات المحوسبة - اللغة العربية",
    "القدرات المحوسبة - اللغة الإنجليزية",
    "التحصيلي - العلوم الطبيعية",
    "التحصيلي - العلوم الشرعية والعربية",
    "اختبار تجريبي شامل"
  ];

  const grades = [
    "الصف الأول الثانوي",
    "الصف الثاني الثانوي",
    "الصف الثالث الثانوي",
    "خريج الثانوية العامة"
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.subject || !formData.grade) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setIsSubmitting(true);
    try {
      await createTest({
        title: formData.title,
        description: formData.description,
        subject: formData.subject,
        grade: formData.grade,
        duration: formData.duration,
        instructions: formData.instructions || undefined,
        startDate: formData.startDate ? new Date(formData.startDate).getTime() : undefined,
        endDate: formData.endDate ? new Date(formData.endDate).getTime() : undefined,
      });
      toast.success("تم إنشاء اختبار القدرات بنجاح!");
      onClose();
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء اختبار القدرات");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900">إنشاء اختبار قدرات جديد</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 text-2xl"
            >
              ×
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* عنوان الاختبار */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              عنوان اختبار القدرات *
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="أدخل عنوان اختبار القدرات"
              required
            />
          </div>

          {/* وصف الاختبار */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              وصف الاختبار
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="أدخل وصف اختبار القدرات"
            />
          </div>

          {/* نوع الاختبار والمرحلة */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                نوع اختبار القدرات *
              </label>
              <select
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">اختر نوع الاختبار</option>
                {subjects.map((subject) => (
                  <option key={subject} value={subject}>
                    {subject}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                المرحلة المستهدفة *
              </label>
              <select
                value={formData.grade}
                onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">اختر المرحلة</option>
                {grades.map((grade) => (
                  <option key={grade} value={grade}>
                    {grade}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* مدة الاختبار */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              مدة الاختبار (بالدقائق)
            </label>
            <input
              type="number"
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) || 120 })}
              min="30"
              max="300"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <p className="text-xs text-gray-500 mt-1">الحد الأدنى 30 دقيقة، الحد الأقصى 300 دقيقة</p>
          </div>

          {/* تواريخ البداية والنهاية */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                تاريخ البداية (اختياري)
              </label>
              <input
                type="datetime-local"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                تاريخ النهاية (اختياري)
              </label>
              <input
                type="datetime-local"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* تعليمات الاختبار */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              تعليمات اختبار القدرات
            </label>
            <textarea
              value={formData.instructions}
              onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="أدخل تعليمات اختبار القدرات للمتدربين"
            />
          </div>

          {/* أزرار الإجراءات */}
          <div className="flex justify-end space-x-4 space-x-reverse pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? "جاري الإنشاء..." : "إنشاء اختبار القدرات"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

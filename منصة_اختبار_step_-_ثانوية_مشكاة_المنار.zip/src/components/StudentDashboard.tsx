import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { TestCard } from "./TestCard";

export function StudentDashboard() {
  const availableTests = useQuery(api.tests.getAvailableTests) || [];

  return (
    <div className="space-y-6">
      {/* إحصائيات المتدرب */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">اختبارات القدرات المتاحة</p>
              <p className="text-2xl font-bold text-gray-900">{availableTests.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">📝</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">الاختبارات المكتملة</p>
              <p className="text-2xl font-bold text-gray-900">0</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">✅</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">نقاط القدرات</p>
              <p className="text-2xl font-bold text-gray-900">--</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">⭐</span>
            </div>
          </div>
        </div>
      </div>

      {/* اختبارات القدرات المتاحة */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold mb-6">اختبارات القدرات المتاحة</h3>
        
        {availableTests.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📚</div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد اختبارات قدرات متاحة</h3>
            <p className="text-gray-600">سيتم إشعارك عند توفر اختبارات قدرات جديدة</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {availableTests.map((test) => (
              <TestCard key={test._id} test={test} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

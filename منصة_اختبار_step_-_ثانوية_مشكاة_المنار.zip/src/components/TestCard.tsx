import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface TestCardProps {
  test: {
    _id: string;
    title: string;
    description: string;
    subject: string;
    duration: number;
    totalMarks: number;
    instructions?: string;
    startDate?: number;
    endDate?: number;
  };
}

export function TestCard({ test }: TestCardProps) {
  const [isStarting, setIsStarting] = useState(false);
  const startTest = useMutation(api.tests.startTestAttempt);

  const handleStartTest = async () => {
    setIsStarting(true);
    try {
      const attemptId = await startTest({ testId: test._id as any });
      toast.success("تم بدء اختبار القدرات بنجاح!");
      // هنا يمكن التوجه إلى صفحة الاختبار
      console.log("Attempt ID:", attemptId);
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء بدء اختبار القدرات");
    } finally {
      setIsStarting(false);
    }
  };

  const formatDate = (timestamp?: number) => {
    if (!timestamp) return null;
    return new Date(timestamp).toLocaleDateString("ar-SA", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const isAvailable = () => {
    const now = Date.now();
    if (test.startDate && test.startDate > now) return false;
    if (test.endDate && test.endDate < now) return false;
    return true;
  };

  return (
    <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h4 className="text-xl font-semibold text-gray-900 mb-2">{test.title}</h4>
          <p className="text-gray-600 mb-3">{test.description}</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center space-x-2 space-x-reverse">
              <span className="text-blue-600">📚</span>
              <span className="text-gray-700">{test.subject}</span>
            </div>
            <div className="flex items-center space-x-2 space-x-reverse">
              <span className="text-green-600">⏱️</span>
              <span className="text-gray-700">{test.duration} دقيقة</span>
            </div>
            <div className="flex items-center space-x-2 space-x-reverse">
              <span className="text-orange-600">📊</span>
              <span className="text-gray-700">{test.totalMarks} نقطة</span>
            </div>
            <div className="flex items-center space-x-2 space-x-reverse">
              <span className={isAvailable() ? "text-green-600" : "text-red-600"}>
                {isAvailable() ? "✅" : "🔒"}
              </span>
              <span className="text-gray-700">
                {isAvailable() ? "متاح" : "غير متاح"}
              </span>
            </div>
          </div>

          {(test.startDate || test.endDate) && (
            <div className="mt-3 text-sm text-gray-600">
              {test.startDate && (
                <p>📅 يبدأ: {formatDate(test.startDate)}</p>
              )}
              {test.endDate && (
                <p>⏰ ينتهي: {formatDate(test.endDate)}</p>
              )}
            </div>
          )}

          {test.instructions && (
            <div className="mt-3 p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>تعليمات اختبار القدرات:</strong> {test.instructions}
              </p>
            </div>
          )}
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleStartTest}
          disabled={!isAvailable() || isStarting}
          className={`px-6 py-3 rounded-lg font-medium transition-colors ${
            isAvailable()
              ? "bg-blue-600 text-white hover:bg-blue-700"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
        >
          {isStarting ? "جاري البدء..." : "بدء اختبار القدرات"}
        </button>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function DeleteAccountSection() {
  const deleteAccount = useMutation(api.account.deleteAccount);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleDeleteAccount = async () => {
    if (deleteConfirmText !== "حذف حسابي") {
      toast.error("يرجى كتابة 'حذف حسابي' للتأكيد");
      return;
    }

    setIsSubmitting(true);
    try {
      await deleteAccount();
      toast.success("تم حذف حسابك بنجاح");
      // سيتم إعادة توجيه المستخدم تلقائياً لصفحة تسجيل الدخول
      window.location.reload();
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف الحساب");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-6 space-y-4">
      <h3 className="text-lg font-bold text-red-800 flex items-center">
        <span className="text-2xl ml-2">⚠️</span>
        منطقة خطر
      </h3>
      
      <div className="bg-white rounded-xl p-4 border border-red-200">
        <h4 className="font-bold text-red-700 mb-2">حذف الحساب نهائياً</h4>
        <p className="text-sm text-red-600 mb-4">
          تحذير: هذا الإجراء لا يمكن التراجع عنه. سيتم حذف جميع بياناتك نهائياً بما في ذلك:
        </p>
        <ul className="text-sm text-red-600 mb-4 list-disc list-inside space-y-1">
          <li>الملف الشخصي والمعلومات الشخصية</li>
          <li>جميع الاختبارات والأسئلة (للمدربين)</li>
          <li>نتائج الاختبارات والإجابات (للمتدربين)</li>
          <li>الرسائل والإشعارات</li>
          <li>سجل الأنشطة والإنجازات</li>
        </ul>
        
        {!showDeleteConfirm ? (
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors font-medium"
          >
            🗑️ حذف حسابي نهائياً
          </button>
        ) : (
          <div className="space-y-3">
            <p className="text-sm font-medium text-red-700">
              للتأكيد، اكتب "حذف حسابي" في الحقل أدناه:
            </p>
            <input
              type="text"
              value={deleteConfirmText}
              onChange={(e) => setDeleteConfirmText(e.target.value)}
              className="w-full px-3 py-2 border border-red-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="حذف حسابي"
            />
            <div className="flex space-x-3 space-x-reverse">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setDeleteConfirmText("");
                }}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleDeleteAccount}
                disabled={deleteConfirmText !== "حذف حسابي" || isSubmitting}
                className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium"
              >
                {isSubmitting ? "جاري الحذف..." : "تأكيد الحذف"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

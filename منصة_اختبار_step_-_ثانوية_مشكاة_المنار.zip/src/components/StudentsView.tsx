import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";

export function StudentsView() {
  const [selectedGrade, setSelectedGrade] = useState<string>("");
  const [selectedClassLevel, setSelectedClassLevel] = useState<string>("");
  
  const students = useQuery(api.users.getAllStudents, {
    grade: selectedGrade || undefined,
    classLevel: selectedClassLevel || undefined,
  }) || [];

  const grades = ["الصف الأول الثانوي", "الصف الثاني الثانوي", "الصف الثالث الثانوي", "خريج الثانوية العامة"];
  const classLevels = ["المستوى الأساسي", "المستوى المتوسط", "المستوى المتقدم", "المستوى المتميز"];

  return (
    <div className="space-y-6">
      {/* فلاتر */}
      <div className="flex space-x-4 space-x-reverse">
        <select
          value={selectedGrade}
          onChange={(e) => setSelectedGrade(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="">جميع المراحل</option>
          {grades.map((grade) => (
            <option key={grade} value={grade}>
              {grade}
            </option>
          ))}
        </select>

        <select
          value={selectedClassLevel}
          onChange={(e) => setSelectedClassLevel(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="">جميع المستويات</option>
          {classLevels.map((level) => (
            <option key={level} value={level}>
              {level}
            </option>
          ))}
        </select>
      </div>

      {/* قائمة المتدربين */}
      {students.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">👥</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">لا يوجد متدربين</h3>
          <p className="text-gray-600">لم يتم العثور على متدربين بالمعايير المحددة</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {students.map((student) => (
            <StudentCard key={student._id} student={student} />
          ))}
        </div>
      )}
    </div>
  );
}

function StudentCard({ student }: { student: any }) {
  const studentStats = useQuery(api.users.getStudentStats, {
    studentId: student.userId,
  });

  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <div className="flex items-center space-x-3 space-x-reverse mb-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold">
              {student.fullName.charAt(0)}
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">{student.fullName}</h4>
              <p className="text-sm text-gray-600">
                {student.grade} - {student.classLevel || "مستوى غير محدد"}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-600">رقم الهوية:</span>
              <span className="font-medium mr-1">{student.studentId || "غير محدد"}</span>
            </div>
            <div>
              <span className="text-gray-600">الهاتف:</span>
              <span className="font-medium mr-1">{student.phone || "غير محدد"}</span>
            </div>
            <div>
              <span className="text-gray-600">اختبارات القدرات:</span>
              <span className="font-medium mr-1">{studentStats?.totalTests || 0}</span>
            </div>
            <div>
              <span className="text-gray-600">نقاط القدرات:</span>
              <span className="font-medium mr-1">
                {studentStats?.averageScore ? `${studentStats.averageScore}` : "--"}
              </span>
            </div>
          </div>

          {studentStats && studentStats.totalTests > 0 && (
            <div className="mt-3 flex items-center space-x-4 space-x-reverse text-sm">
              <div className="flex items-center space-x-1 space-x-reverse">
                <span className="text-green-600">✅</span>
                <span>معدل النجاح: {studentStats.passRate}%</span>
              </div>
              {studentStats.lastTestDate && (
                <div className="flex items-center space-x-1 space-x-reverse">
                  <span className="text-blue-600">📅</span>
                  <span>
                    آخر اختبار: {new Date(studentStats.lastTestDate).toLocaleDateString("ar-SA")}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex items-center space-x-2 space-x-reverse">
          <span className={`px-2 py-1 rounded-full text-xs ${
            student.isActive 
              ? "bg-green-100 text-green-800" 
              : "bg-gray-100 text-gray-800"
          }`}>
            {student.isActive ? "نشط" : "غير نشط"}
          </span>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function ProfileSetup() {
  const [formData, setFormData] = useState({
    role: "" as "teacher" | "student" | "",
    fullName: "",
    studentId: "",
    grade: "",
    classLevel: "",
    phone: "",
    specialization: "",
    birthDate: "",
    city: "",
    parentPhone: "",
    emergencyContact: "",
  });

  const createProfile = useMutation(api.users.createOrUpdateProfile);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.role || !formData.fullName) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setIsSubmitting(true);
    try {
      await createProfile({
        role: formData.role,
        fullName: formData.fullName,
        studentId: formData.studentId || undefined,
        grade: formData.grade || undefined,
        classLevel: formData.classLevel || undefined,
        phone: formData.phone || undefined,
        specialization: formData.specialization || undefined,
        birthDate: formData.birthDate || undefined,
        city: formData.city || undefined,
        parentPhone: formData.parentPhone || undefined,
        emergencyContact: formData.emergencyContact || undefined,
      });
      toast.success("🎉 تم إنشاء الملف الشخصي بنجاح!");
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء الملف الشخصي");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const grades = [
    "الصف الأول الثانوي",
    "الصف الثاني الثانوي", 
    "الصف الثالث الثانوي",
    "خريج الثانوية العامة",
    "طالب جامعي",
    "خريج جامعي"
  ];

  const classLevels = [
    "المستوى الأساسي",
    "المستوى المتوسط", 
    "المستوى المتقدم",
    "المستوى المتميز",
    "مستوى التحضيري"
  ];

  const specializations = [
    "العلوم الطبيعية",
    "العلوم الشرعية والعربية",
    "الإدارة والاقتصاد",
    "الحاسب الآلي",
    "الهندسة",
    "الطب",
    "أخرى"
  ];

  const cities = [
    "الرياض", "جدة", "مكة المكرمة", "المدينة المنورة", "الدمام", "الخبر", "الظهران",
    "تبوك", "بريدة", "خميس مشيط", "حائل", "الجبيل", "الطائف", "ينبع", "أبها",
    "نجران", "الباحة", "عرعر", "سكاكا", "جازان", "القطيف", "الأحساء"
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 p-8 text-white">
          <div className="text-center">
            <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
              <span className="text-4xl">🚀</span>
            </div>
            <h2 className="text-3xl font-bold mb-2">مرحباً بك في منصة القدرات</h2>
            <p className="text-blue-100">دعنا نتعرف عليك أكثر لنقدم لك أفضل تجربة تعليمية</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {/* نوع المستخدم */}
          <div className="space-y-4">
            <label className="block text-lg font-bold text-gray-800 mb-4">
              <span className="text-2xl ml-2">👤</span>
              اختر نوع حسابك *
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, role: "teacher" })}
                className={`group p-6 rounded-2xl border-3 transition-all duration-300 transform hover:scale-105 ${
                  formData.role === "teacher"
                    ? "border-blue-500 bg-gradient-to-br from-blue-50 to-blue-100 text-blue-700 shadow-lg"
                    : "border-gray-200 hover:border-blue-300 hover:shadow-md"
                }`}
              >
                <div className="text-center">
                  <div className="text-5xl mb-4 group-hover:animate-bounce">👨‍🏫</div>
                  <div className="font-bold text-xl mb-2">مدرب قدرات</div>
                  <div className="text-sm text-gray-600">إنشاء وإدارة اختبارات القدرات</div>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, role: "student" })}
                className={`group p-6 rounded-2xl border-3 transition-all duration-300 transform hover:scale-105 ${
                  formData.role === "student"
                    ? "border-green-500 bg-gradient-to-br from-green-50 to-green-100 text-green-700 shadow-lg"
                    : "border-gray-200 hover:border-green-300 hover:shadow-md"
                }`}
              >
                <div className="text-center">
                  <div className="text-5xl mb-4 group-hover:animate-bounce">👨‍🎓</div>
                  <div className="font-bold text-xl mb-2">متدرب</div>
                  <div className="text-sm text-gray-600">أداء اختبارات القدرات والتدريب</div>
                </div>
              </button>
            </div>
          </div>

          {/* المعلومات الأساسية */}
          <div className="bg-gray-50 rounded-2xl p-6 space-y-6">
            <h3 className="text-xl font-bold text-gray-800 flex items-center">
              <span className="text-2xl ml-2">📝</span>
              المعلومات الأساسية
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الاسم الكامل *
                </label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="أدخل اسمك الكامل"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="05xxxxxxxx"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  تاريخ الميلاد
                </label>
                <input
                  type="date"
                  value={formData.birthDate}
                  onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  المدينة
                </label>
                <select
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                >
                  <option value="">اختر المدينة</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* حقول خاصة بالمتدربين */}
          {formData.role === "student" && (
            <div className="bg-green-50 rounded-2xl p-6 space-y-6">
              <h3 className="text-xl font-bold text-gray-800 flex items-center">
                <span className="text-2xl ml-2">🎓</span>
                معلومات الدراسة
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    رقم الهوية / الإقامة
                  </label>
                  <input
                    type="text"
                    value={formData.studentId}
                    onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    placeholder="أدخل رقم الهوية أو الإقامة"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    المرحلة الدراسية
                  </label>
                  <select
                    value={formData.grade}
                    onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                  >
                    <option value="">اختر المرحلة</option>
                    {grades.map((grade) => (
                      <option key={grade} value={grade}>
                        {grade}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    مستوى الصف
                  </label>
                  <select
                    value={formData.classLevel}
                    onChange={(e) => setFormData({ ...formData, classLevel: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                  >
                    <option value="">اختر المستوى</option>
                    {classLevels.map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    التخصص
                  </label>
                  <select
                    value={formData.specialization}
                    onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                  >
                    <option value="">اختر التخصص</option>
                    {specializations.map((spec) => (
                      <option key={spec} value={spec}>
                        {spec}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    هاتف ولي الأمر
                  </label>
                  <input
                    type="tel"
                    value={formData.parentPhone}
                    onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    placeholder="05xxxxxxxx"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    جهة اتصال طوارئ
                  </label>
                  <input
                    type="text"
                    value={formData.emergencyContact}
                    onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    placeholder="اسم ورقم هاتف جهة الاتصال"
                  />
                </div>
              </div>
            </div>
          )}

          {/* زر الحفظ */}
          <div className="text-center pt-6">
            <button
              type="submit"
              disabled={isSubmitting || !formData.role || !formData.fullName}
              className="group relative px-12 py-4 bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 text-white text-lg font-bold rounded-2xl hover:from-blue-700 hover:via-purple-700 hover:to-green-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              <span className="relative z-10 flex items-center justify-center">
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white ml-2"></div>
                    جاري الحفظ...
                  </>
                ) : (
                  <>
                    <span className="text-2xl ml-2">🚀</span>
                    ابدأ رحلتك معنا
                  </>
                )}
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400 via-purple-400 to-green-400 rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

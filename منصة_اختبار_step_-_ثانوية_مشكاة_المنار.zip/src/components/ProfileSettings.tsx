import { useState, useEffect } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { DeleteAccountSection } from "./DeleteAccountSection";

interface ProfileSettingsProps {
  onClose: () => void;
}

export function ProfileSettings({ onClose }: ProfileSettingsProps) {
  const currentUser = useQuery(api.users.getCurrentUser);
  const updateProfile = useMutation(api.users.createOrUpdateProfile);
  
  const [formData, setFormData] = useState({
    role: "" as "teacher" | "student" | "",
    fullName: "",
    studentId: "",
    grade: "",
    classLevel: "",
    phone: "",
    specialization: "",
    birthDate: "",
    city: "",
    parentPhone: "",
    emergencyContact: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (currentUser?.profile) {
      setFormData({
        role: currentUser.profile.role,
        fullName: currentUser.profile.fullName,
        studentId: currentUser.profile.studentId || "",
        grade: currentUser.profile.grade || "",
        classLevel: currentUser.profile.classLevel || "",
        phone: currentUser.profile.phone || "",
        specialization: currentUser.profile.specialization || "",
        birthDate: currentUser.profile.birthDate || "",
        city: currentUser.profile.city || "",
        parentPhone: currentUser.profile.parentPhone || "",
        emergencyContact: currentUser.profile.emergencyContact || "",
      });
    }
  }, [currentUser]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.role || !formData.fullName) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setIsSubmitting(true);
    try {
      await updateProfile({
        role: formData.role,
        fullName: formData.fullName,
        studentId: formData.studentId || undefined,
        grade: formData.grade || undefined,
        classLevel: formData.classLevel || undefined,
        phone: formData.phone || undefined,
        specialization: formData.specialization || undefined,
        birthDate: formData.birthDate || undefined,
        city: formData.city || undefined,
        parentPhone: formData.parentPhone || undefined,
        emergencyContact: formData.emergencyContact || undefined,
      });
      toast.success("✨ تم تحديث الملف الشخصي بنجاح!");
      onClose();
    } catch (error) {
      toast.error("حدث خطأ أثناء تحديث الملف الشخصي");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const grades = [
    "الصف الأول الثانوي",
    "الصف الثاني الثانوي", 
    "الصف الثالث الثانوي",
    "خريج الثانوية العامة",
    "طالب جامعي",
    "خريج جامعي"
  ];

  const classLevels = [
    "المستوى الأساسي",
    "المستوى المتوسط", 
    "المستوى المتقدم",
    "المستوى المتميز",
    "مستوى التحضيري"
  ];

  const specializations = [
    "العلوم الطبيعية",
    "العلوم الشرعية والعربية",
    "الإدارة والاقتصاد",
    "الحاسب الآلي",
    "الهندسة",
    "الطب",
    "أخرى"
  ];

  const cities = [
    "الرياض", "جدة", "مكة المكرمة", "المدينة المنورة", "الدمام", "الخبر", "الظهران",
    "تبوك", "بريدة", "خميس مشيط", "حائل", "الجبيل", "الطائف", "ينبع", "أبها",
    "نجران", "الباحة", "عرعر", "سكاكا", "جازان", "القطيف", "الأحساء"
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white rounded-t-3xl">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3 space-x-reverse">
              <span className="text-3xl">⚙️</span>
              <h2 className="text-2xl font-bold">إعدادات الملف الشخصي</h2>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 text-3xl transition-colors"
            >
              ×
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* نوع المستخدم - للعرض فقط */}
          <div className="bg-gray-50 rounded-2xl p-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              نوع المستخدم
            </label>
            <div className="flex items-center space-x-4 space-x-reverse p-4 bg-white rounded-xl border-2 border-gray-200">
              <span className="text-3xl">
                {formData.role === "teacher" ? "👨‍🏫" : "👨‍🎓"}
              </span>
              <div>
                <span className="font-bold text-lg">
                  {formData.role === "teacher" ? "مدرب قدرات" : "متدرب"}
                </span>
                <p className="text-sm text-gray-600">
                  {formData.role === "teacher" 
                    ? "إنشاء وإدارة اختبارات القدرات" 
                    : "أداء اختبارات القدرات والتدريب"
                  }
                </p>
              </div>
            </div>
          </div>

          {/* المعلومات الأساسية */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-800 flex items-center">
              <span className="text-2xl ml-2">📝</span>
              المعلومات الأساسية
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الاسم الكامل *
                </label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="أدخل اسمك الكامل"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="05xxxxxxxx"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  تاريخ الميلاد
                </label>
                <input
                  type="date"
                  value={formData.birthDate}
                  onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  المدينة
                </label>
                <select
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                >
                  <option value="">اختر المدينة</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* حقول خاصة بالمتدربين */}
          {formData.role === "student" && (
            <div className="bg-green-50 rounded-2xl p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-800 flex items-center">
                <span className="text-2xl ml-2">🎓</span>
                معلومات الدراسة
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    رقم الهوية / الإقامة
                  </label>
                  <input
                    type="text"
                    value={formData.studentId}
                    onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    placeholder="أدخل رقم الهوية أو الإقامة"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    المرحلة الدراسية
                  </label>
                  <select
                    value={formData.grade}
                    onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                  >
                    <option value="">اختر المرحلة</option>
                    {grades.map((grade) => (
                      <option key={grade} value={grade}>
                        {grade}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    مستوى الصف
                  </label>
                  <select
                    value={formData.classLevel}
                    onChange={(e) => setFormData({ ...formData, classLevel: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                  >
                    <option value="">اختر المستوى</option>
                    {classLevels.map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    التخصص
                  </label>
                  <select
                    value={formData.specialization}
                    onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                  >
                    <option value="">اختر التخصص</option>
                    {specializations.map((spec) => (
                      <option key={spec} value={spec}>
                        {spec}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    هاتف ولي الأمر
                  </label>
                  <input
                    type="tel"
                    value={formData.parentPhone}
                    onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    placeholder="05xxxxxxxx"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    جهة اتصال طوارئ
                  </label>
                  <input
                    type="text"
                    value={formData.emergencyContact}
                    onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all"
                    placeholder="اسم ورقم هاتف جهة الاتصال"
                  />
                </div>
              </div>
            </div>
          )}

          {/* منطقة حذف الحساب */}
          <DeleteAccountSection />

          <div className="flex justify-end space-x-4 space-x-reverse pt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors font-medium"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !formData.fullName}
              className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed font-medium shadow-lg"
            >
              {isSubmitting ? "جاري الحفظ..." : "💾 حفظ التغييرات"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

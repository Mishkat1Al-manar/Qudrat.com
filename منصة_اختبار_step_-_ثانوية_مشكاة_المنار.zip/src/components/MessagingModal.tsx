import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface MessagingModalProps {
  onClose: () => void;
}

export function MessagingModal({ onClose }: MessagingModalProps) {
  const [activeTab, setActiveTab] = useState<"compose" | "messages">("compose");
  const [formData, setFormData] = useState({
    subject: "",
    message: "",
    priority: "medium" as "low" | "medium" | "high",
    category: "",
  });
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const sendMessage = useMutation(api.messages.sendMessageToAdmin);
  const replyToMessage = useMutation(api.messages.replyToMessage);
  const markAsRead = useMutation(api.messages.markMessageAsRead);
  const messages = useQuery(api.messages.getUserMessages) || [];

  const categories = [
    "استفسار عام",
    "مشكلة تقنية", 
    "طلب مساعدة",
    "اقتراح تحسين",
    "شكوى",
    "طلب إضافي",
    "أخرى"
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subject || !formData.message) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setIsSubmitting(true);
    try {
      if (replyTo) {
        await replyToMessage({
          originalMessageId: replyTo as any,
          message: formData.message,
        });
        toast.success("✅ تم إرسال الرد بنجاح!");
      } else {
        await sendMessage({
          subject: formData.subject,
          message: formData.message,
        });
        toast.success("🚀 تم إرسال الرسالة بنجاح!");
      }
      
      setFormData({ subject: "", message: "", priority: "medium", category: "" });
      setReplyTo(null);
      setActiveTab("messages");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ أثناء إرسال الرسالة");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReply = (messageId: string, originalSubject: string) => {
    setReplyTo(messageId);
    setFormData({
      subject: `رد: ${originalSubject}`,
      message: "",
      priority: "medium",
      category: "",
    });
    setActiveTab("compose");
  };

  const handleMarkAsRead = async (messageId: string) => {
    try {
      await markAsRead({ messageId: messageId as any });
    } catch (error) {
      console.error("Error marking message as read:", error);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("ar-SA", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-red-600 bg-red-100";
      case "medium": return "text-yellow-600 bg-yellow-100";
      case "low": return "text-green-600 bg-green-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "high": return "🔴";
      case "medium": return "🟡";
      case "low": return "🟢";
      default: return "⚪";
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-5xl w-full max-h-[90vh] overflow-hidden shadow-2xl">
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-6 text-white">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3 space-x-reverse">
              <span className="text-3xl">💬</span>
              <div>
                <h2 className="text-2xl font-bold">مراسلة المسؤول</h2>
                <p className="text-purple-100">تواصل مع إدارة المنصة</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 text-3xl transition-colors"
            >
              ×
            </button>
          </div>
        </div>

        {/* التبويبات المحسنة */}
        <div className="border-b border-gray-200 bg-gray-50">
          <nav className="flex space-x-8 space-x-reverse px-6">
            <button
              onClick={() => setActiveTab("compose")}
              className={`py-4 px-6 border-b-3 font-bold text-sm transition-all duration-300 flex items-center space-x-2 space-x-reverse ${
                activeTab === "compose"
                  ? "border-purple-500 text-purple-600 bg-white rounded-t-lg"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-white/50 rounded-t-lg"
              }`}
            >
              <span className="text-xl">✍️</span>
              <span>رسالة جديدة</span>
            </button>
            <button
              onClick={() => setActiveTab("messages")}
              className={`py-4 px-6 border-b-3 font-bold text-sm transition-all duration-300 flex items-center space-x-2 space-x-reverse ${
                activeTab === "messages"
                  ? "border-purple-500 text-purple-600 bg-white rounded-t-lg"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-white/50 rounded-t-lg"
              }`}
            >
              <span className="text-xl">📬</span>
              <span>الرسائل</span>
              <span className="bg-purple-500 text-white text-xs rounded-full px-2 py-1 min-w-[20px]">
                {messages.length}
              </span>
            </button>
          </nav>
        </div>

        <div className="p-6 max-h-[60vh] overflow-y-auto">
          {activeTab === "compose" && (
            <form onSubmit={handleSubmit} className="space-y-6">
              {replyTo && (
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-2xl border border-blue-200">
                  <div className="flex items-center space-x-2 space-x-reverse mb-2">
                    <span className="text-xl">↩️</span>
                    <p className="text-sm font-bold text-blue-800">
                      رد على: {formData.subject.replace("رد: ", "")}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setReplyTo(null);
                      setFormData({ subject: "", message: "", priority: "medium", category: "" });
                    }}
                    className="text-sm text-blue-600 hover:underline font-medium"
                  >
                    🗑️ إلغاء الرد
                  </button>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    📝 موضوع الرسالة *
                  </label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                    placeholder="أدخل موضوع الرسالة"
                    required
                    disabled={!!replyTo}
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    📂 تصنيف الرسالة
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                  >
                    <option value="">اختر التصنيف</option>
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  ⚡ أولوية الرسالة
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: "low", label: "منخفضة", icon: "🟢", color: "green" },
                    { value: "medium", label: "متوسطة", icon: "🟡", color: "yellow" },
                    { value: "high", label: "عالية", icon: "🔴", color: "red" }
                  ].map((priority) => (
                    <button
                      key={priority.value}
                      type="button"
                      onClick={() => setFormData({ ...formData, priority: priority.value as any })}
                      className={`p-3 rounded-xl border-2 transition-all duration-300 ${
                        formData.priority === priority.value
                          ? `border-${priority.color}-500 bg-${priority.color}-50 text-${priority.color}-700`
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className="text-center">
                        <div className="text-2xl mb-1">{priority.icon}</div>
                        <div className="text-sm font-medium">{priority.label}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  💭 نص الرسالة *
                </label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={8}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                  placeholder="اكتب رسالتك هنا... كن واضحاً ومفصلاً"
                  required
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmitting || !formData.subject || !formData.message}
                  className="group px-8 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl hover:from-purple-700 hover:to-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed font-bold shadow-lg transform hover:scale-105"
                >
                  {isSubmitting ? (
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>جاري الإرسال...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <span className="text-xl">🚀</span>
                      <span>{replyTo ? "إرسال الرد" : "إرسال الرسالة"}</span>
                    </div>
                  )}
                </button>
              </div>
            </form>
          )}

          {activeTab === "messages" && (
            <div className="space-y-4">
              {messages.length === 0 ? (
                <div className="text-center py-16">
                  <div className="text-8xl mb-6">📭</div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">صندوق الرسائل فارغ</h3>
                  <p className="text-gray-600 text-lg mb-6">لم تقم بإرسال أو استقبال أي رسائل بعد</p>
                  <button
                    onClick={() => setActiveTab("compose")}
                    className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-xl hover:from-purple-700 hover:to-blue-700 transition-all font-bold"
                  >
                    ✍️ إرسال رسالة جديدة
                  </button>
                </div>
              ) : (
                messages.map((message) => (
                  <div
                    key={message._id}
                    className={`border-2 rounded-2xl p-6 transition-all duration-300 hover:shadow-lg ${
                      !message.isRead && !message.isSent
                        ? "bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200 shadow-md"
                        : "bg-white border-gray-200 hover:border-gray-300"
                    }`}
                    onClick={() => {
                      if (!message.isRead && !message.isSent) {
                        handleMarkAsRead(message._id);
                      }
                    }}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 space-x-reverse mb-2">
                          <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                            message.isSent
                              ? "bg-green-100 text-green-800"
                              : "bg-blue-100 text-blue-800"
                          }`}>
                            {message.isSent ? "📤 مُرسلة" : "📥 مُستقبلة"}
                          </span>
                          {!message.isRead && !message.isSent && (
                            <span className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></span>
                          )}
                          {message.priority && (
                            <span className={`px-2 py-1 rounded-full text-xs font-bold ${getPriorityColor(message.priority)}`}>
                              {getPriorityIcon(message.priority)} {message.priority === "high" ? "عالية" : message.priority === "medium" ? "متوسطة" : "منخفضة"}
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-lg text-gray-900 mb-2">{message.subject}</h4>
                        <p className="text-sm text-gray-600 mb-2 flex items-center space-x-2 space-x-reverse">
                          <span className="text-lg">
                            {message.isSent ? "👤" : "👨‍💼"}
                          </span>
                          <span>
                            {message.isSent 
                              ? `إلى: ${message.toUser?.email === "admin@gmail.com" ? "المسؤول" : message.toProfile?.fullName || "غير محدد"}`
                              : `من: ${message.fromUser?.email === "admin@gmail.com" ? "المسؤول" : message.fromProfile?.fullName || "غير محدد"}`
                            }
                          </span>
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-lg">
                          {formatDate(message.sentAt)}
                        </span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-xl p-4 mb-4">
                      <p className="text-gray-700 leading-relaxed">{message.message}</p>
                    </div>
                    
                    {!message.isSent && (
                      <div className="flex justify-end">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleReply(message._id, message.subject);
                          }}
                          className="flex items-center space-x-2 space-x-reverse text-sm text-purple-600 hover:text-purple-800 font-bold hover:bg-purple-50 px-3 py-2 rounded-lg transition-all"
                        >
                          <span className="text-lg">↩️</span>
                          <span>رد على الرسالة</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

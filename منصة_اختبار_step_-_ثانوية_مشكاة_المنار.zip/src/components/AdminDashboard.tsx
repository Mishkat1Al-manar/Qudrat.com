import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function AdminDashboard() {
  const stats = useQuery(api.admin.getPlatformStats);
  const allMessages = useQuery(api.messages.getAllMessagesForAdmin) || [];

  if (!stats) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* إحصائيات المنصة */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">إجمالي المستخدمين</p>
              <p className="text-3xl font-bold">{stats.users.total}</p>
            </div>
            <div className="text-4xl opacity-80">👥</div>
          </div>
          <div className="mt-4 flex space-x-4 space-x-reverse text-sm">
            <span className="bg-white/20 px-2 py-1 rounded-lg">
              👨‍🏫 {stats.users.teachers} مدرب
            </span>
            <span className="bg-white/20 px-2 py-1 rounded-lg">
              👨‍🎓 {stats.users.students} متدرب
            </span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm font-medium">الاختبارات</p>
              <p className="text-3xl font-bold">{stats.tests.total}</p>
            </div>
            <div className="text-4xl opacity-80">📝</div>
          </div>
          <div className="mt-4">
            <span className="bg-white/20 px-2 py-1 rounded-lg text-sm">
              ✅ {stats.tests.active} نشط
            </span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm font-medium">محاولات الاختبارات</p>
              <p className="text-3xl font-bold">{stats.attempts.total}</p>
            </div>
            <div className="text-4xl opacity-80">📊</div>
          </div>
          <div className="mt-4">
            <span className="bg-white/20 px-2 py-1 rounded-lg text-sm">
              ✅ {stats.attempts.completed} مكتمل
            </span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm font-medium">الرسائل</p>
              <p className="text-3xl font-bold">{stats.messages}</p>
            </div>
            <div className="text-4xl opacity-80">💬</div>
          </div>
        </div>
      </div>

      {/* الرسائل الواردة */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
          <span className="text-2xl ml-2">📬</span>
          الرسائل الواردة
        </h3>

        {allMessages.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📭</div>
            <h4 className="text-lg font-medium text-gray-900 mb-2">لا توجد رسائل</h4>
            <p className="text-gray-600">لم يتم استلام أي رسائل بعد</p>
          </div>
        ) : (
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {allMessages.slice(0, 10).map((message) => (
              <div
                key={message._id}
                className={`border rounded-xl p-4 transition-all hover:shadow-md ${
                  !message.isRead ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200"
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{message.subject}</h4>
                    <p className="text-sm text-gray-600">
                      من: {message.fromProfile?.fullName || "مستخدم غير معروف"}
                      {message.fromProfile?.role && (
                        <span className="mr-2 text-xs bg-gray-200 px-2 py-1 rounded-full">
                          {message.fromProfile.role === "teacher" ? "مدرب" : "متدرب"}
                        </span>
                      )}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-gray-500">
                      {new Date(message.sentAt).toLocaleDateString("ar-SA")}
                    </span>
                    {!message.isRead && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-1 mr-auto"></div>
                    )}
                  </div>
                </div>
                <p className="text-sm text-gray-700 line-clamp-2">{message.message}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* معلومات المسؤول */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-2xl p-6 text-white">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <span className="text-2xl ml-2">👨‍💼</span>
          معلومات المسؤول
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-300">البريد الإلكتروني:</span>
            <span className="font-medium mr-2">admin@gmail.com</span>
          </div>
          <div>
            <span className="text-gray-300">كلمة المرور:</span>
            <span className="font-medium mr-2">admin123456</span>
          </div>
          <div>
            <span className="text-gray-300">الصلاحيات:</span>
            <span className="font-medium mr-2">مسؤول عام</span>
          </div>
          <div>
            <span className="text-gray-300">تاريخ الإنشاء:</span>
            <span className="font-medium mr-2">{new Date().toLocaleDateString("ar-SA")}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { SignOutButton } from "../SignOutButton";
import { ProfileSettings } from "./ProfileSettings";
import { MessagingModal } from "./MessagingModal";

export function UserMenu() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showProfileSettings, setShowProfileSettings] = useState(false);
  const [showMessaging, setShowMessaging] = useState(false);
  
  const currentUser = useQuery(api.users.getCurrentUser);
  const unreadCount = useQuery(api.messages.getUnreadMessagesCount) || 0;

  if (!currentUser?.profile) return null;

  return (
    <>
      <div className="relative">
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="flex items-center space-x-3 space-x-reverse p-2 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
            {currentUser.profile.fullName.charAt(0)}
          </div>
          <div className="text-right">
            <p className="text-sm font-medium text-gray-900">
              {currentUser.profile.fullName}
            </p>
            <p className="text-xs text-gray-600">
              {currentUser.profile.role === "teacher" ? "مدرب قدرات" : "متدرب"}
            </p>
          </div>
          <svg
            className={`w-4 h-4 text-gray-400 transition-transform ${
              isMenuOpen ? "rotate-180" : ""
            }`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        {isMenuOpen && (
          <div className="absolute left-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold">
                  {currentUser.profile.fullName.charAt(0)}
                </div>
                <div>
                  <p className="font-medium text-gray-900">
                    {currentUser.profile.fullName}
                  </p>
                  <p className="text-sm text-gray-600">
                    {currentUser.profile.role === "teacher" ? "مدرب قدرات" : "متدرب"}
                  </p>
                  {currentUser.profile.grade && (
                    <p className="text-xs text-gray-500">
                      {currentUser.profile.grade}
                      {currentUser.profile.classLevel && ` - ${currentUser.profile.classLevel}`}
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div className="p-2">
              <button
                onClick={() => {
                  setShowProfileSettings(true);
                  setIsMenuOpen(false);
                }}
                className="w-full flex items-center space-x-3 space-x-reverse px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <span>⚙️</span>
                <span>إعدادات الملف الشخصي</span>
              </button>

              <button
                onClick={() => {
                  setShowMessaging(true);
                  setIsMenuOpen(false);
                }}
                className="w-full flex items-center justify-between px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="flex items-center space-x-3 space-x-reverse">
                  <span>💬</span>
                  <span>مراسلة المسؤول</span>
                </div>
                {unreadCount > 0 && (
                  <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1 min-w-[20px] text-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              <div className="border-t border-gray-200 mt-2 pt-2">
                <div className="px-3 py-2">
                  <SignOutButton />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* النوافذ المنبثقة */}
      {showProfileSettings && (
        <ProfileSettings onClose={() => setShowProfileSettings(false)} />
      )}

      {showMessaging && (
        <MessagingModal onClose={() => setShowMessaging(false)} />
      )}

      {/* إغلاق القائمة عند النقر خارجها */}
      {isMenuOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setIsMenuOpen(false)}
        />
      )}
    </>
  );
}

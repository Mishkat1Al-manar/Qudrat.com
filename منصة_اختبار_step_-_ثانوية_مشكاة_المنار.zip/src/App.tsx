import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { Toaster } from "sonner";
import { Dashboard } from "./components/Dashboard";
import { ProfileSetup } from "./components/ProfileSetup";
import { UserMenu } from "./components/UserMenu";
import { toast } from "sonner";

export default function App() {
  const createAdmin = useMutation(api.admin.createAdminAccount);
  const adminStatus = useQuery(api.admin.checkAdminStatus);

  const handleCreateAdmin = async () => {
    try {
      const result = await createAdmin();
      toast.success(result.message);
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء حساب المسؤول");
    }
  };
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50" dir="rtl">
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">ق</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">ثانوية مشكاة المنار الأهلية</h1>
                <p className="text-sm text-gray-600">اختبارات القدرات العامة</p>
              </div>
            </div>
            <Authenticated>
              <UserMenu />
            </Authenticated>
            <Unauthenticated>
              {adminStatus && !adminStatus.exists && (
                <button
                  onClick={handleCreateAdmin}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm font-medium"
                >
                  إنشاء حساب المسؤول
                </button>
              )}
            </Unauthenticated>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Content />
      </main>
      
      <Toaster position="top-center" />
    </div>
  );
}

function Content() {
  const currentUser = useQuery(api.users.getCurrentUser);

  if (currentUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <Unauthenticated>
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <span className="text-white font-bold text-3xl">ق</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">مرحباً بك</h2>
            <p className="text-gray-600">سجل دخولك للوصول إلى منصة اختبارات القدرات</p>
          </div>
          <SignInForm />
        </div>
      </Unauthenticated>

      <Authenticated>
        {!currentUser?.profile ? (
          <ProfileSetup />
        ) : currentUser.profile ? (
          <Dashboard user={currentUser as any} />
        ) : null}
      </Authenticated>
    </div>
  );
}
